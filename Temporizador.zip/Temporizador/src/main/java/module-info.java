module com.agenda.temporizador {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.agenda.temporizador to javafx.fxml;
    exports com.agenda.temporizador;
    exports com.agenda.temporizador.main.Main;
    opens com.agenda.temporizador.main.Main to javafx.fxml;
}