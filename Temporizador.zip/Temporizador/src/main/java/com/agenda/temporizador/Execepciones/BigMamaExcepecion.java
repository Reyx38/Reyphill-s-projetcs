package com.agenda.temporizador.Execepciones;

import java.security.PublicKey;

public class BigMamaExcepecion extends Exception{
    public BigMamaExcepecion(String causa) {
        super(causa);
    }
    @Override
    public String getMessage(){
        return "{Big mama Expetion} - " + super.getMessage();
    }
}
