package com.agenda.temporizador.Archivos;

import java.io.*;

public class Main3 {
    File archivo = new File ("C:/Users");
    FileReader fr;
    fr = new FileReader(archivo);
    byte[] texto = new byte[1];
    while (true)
    {
        if (!((fr.read(texto)) > 0)) {
            String s = new String((texto));
            System.out.println(s);
        }
    }


}
