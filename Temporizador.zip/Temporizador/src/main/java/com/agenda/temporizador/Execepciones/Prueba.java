package com.agenda.temporizador.Execepciones;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Prueba {
   /* public int leerentero() throws IOException, NumberFormatException {
        /*BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try{
            int N1 = Integer.parseInt(br.readLine());
            return N1;
            if (N1 > 500 ){

            }
        }catch (IOException e){
            throw new RuntimeException()
        }catch (NumberFormatException e2){

        }
    }*/
    }
