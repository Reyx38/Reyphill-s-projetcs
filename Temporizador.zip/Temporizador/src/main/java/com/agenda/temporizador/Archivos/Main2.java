package com.agenda.temporizador.Archivos;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main2 {
    public static void main(String[] args) {
        File archivo = new File("C:/Prueba/BigMama2");
        FileWriter fr;
        String texto = """
                Mi papa fuma pipa
                Ese enano robo mi pelota
                ese oso come sopa
                """;
        try{
            fr = new FileWriter(archivo);
            fr.write(texto);
            fr.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
