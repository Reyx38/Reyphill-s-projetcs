package com.agenda.temporizador.main.Main;

import java.text.DecimalFormat;

public class Tiempo {
    private int segundo;
    private int hora;
    private int minutos;

    public Tiempo(int hora, int minutos, int segundo) {
        this.segundo = segundo;
        this.hora = hora;
        this.minutos = minutos;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }
    
    public void Disminuirsegundos(){
        if (segundo == 0){
            segundo = 59;
            Disminuirminutos();
        }else{
            segundo--;
        }
    }
    private void Disminuirminutos() {
        if(minutos == 0){
            minutos = 59;
            DisminuirHoras();
        }else{
            minutos--;
        }
    }

    private void DisminuirHoras() {
        hora--;
    }

    public boolean pausar(){
        if(hora == 0 && minutos == 0 && segundo == 0){
            return true;
        }
        return false;
    }
    public String get(){
        DecimalFormat df = new DecimalFormat("00");
        return df.format(hora) + ":" + df.format(minutos) + ":" + df.format(segundo);
    }

    @Override
    public String toString() {return get();}
}
