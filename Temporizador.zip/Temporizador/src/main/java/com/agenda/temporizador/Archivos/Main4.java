package com.agenda.temporizador.Archivos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Main4 {
    File archivo = new File("C:/Users");
    FileInputStream fis;
        try {
            fis = new FileInputStream(archivo);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

}
