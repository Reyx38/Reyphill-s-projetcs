package com.agenda.temporizador;
import com.agenda.temporizador.Hilos.HORAS;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.net.URL;
import java.util.ResourceBundle;

public class TemporizadorControlador implements Initializable{
    @FXML
    private Button Iniciar;

    @FXML
    private Button Pausar;

    @FXML
    private Label TextHora ;

    @FXML
    private Button salir;

    private HORAS horasThread = new HORAS(0,40,0,this);

    @FXML
    void ClickIniciar(ActionEvent event) throws InterruptedException {
        if(horasThread != null){
            horasThread.start();;
        }else{
            horasThread.reanudar();
        }
    }

    @FXML
    void ClickSalir(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void Clickpausar(ActionEvent event) {
        horasThread.pausa();

    }
    public void actulizar(String time){
        TextHora.setText(time);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (TextHora != null) {
            TextHora.setText(horasThread.getime());
        } else {
            System.out.println("Error: TextHora es null");
        }
    }
}
