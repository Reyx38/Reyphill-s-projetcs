package com.agenda.temporizador.Hilos;

import com.agenda.temporizador.TemporizadorControlador;
import com.agenda.temporizador.main.Main.Tiempo;
import javafx.application.Platform;

public class HORAS extends Thread {
    private Tiempo tiempo;
    private boolean pause;
    private TemporizadorControlador controlador;

    public HORAS(int horas,int minutos,int segundo,TemporizadorControlador controlador) {
        this.tiempo = new Tiempo(horas,minutos,segundo);
        this.controlador = controlador;
        pause = false;
    }
    public String getime(){return tiempo.toString();}
    public synchronized void pausa(){ pause = true;}
    public synchronized void reanudar(){
        pause = false;
        notify();
    }

    public void empezar(){
        start();
    }

    public void run(){
        while (!tiempo.pausar()) {
            synchronized (this) {
                while (pause) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
            try {
                tiempo.Disminuirsegundos();
                Platform.runLater(() -> controlador.actulizar(tiempo.toString()));
                sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

}


