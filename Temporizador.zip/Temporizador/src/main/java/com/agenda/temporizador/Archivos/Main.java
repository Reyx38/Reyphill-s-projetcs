package com.agenda.temporizador.Archivos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        /*File f = new File("C:/Users");
       String[] archivos = f.list();
        for(String s: archivos) {
            File f2 = new File(f,s);
            System.out.println(f2.isFile() ? "[Archivos] " : "[Directorio] - " + s);
        }
        File f3 = new File(f, "Midirectorio");
        if (!f3.exists()){
                System.out.println("No existe");
                f3.mkdir();
        }else{
                System.out.println("El Directorio existe");
                f3.delete();
        }*/
        String texto = """
                e malvado 
                un malito 
                """;
        File archivo = new File ("C:/Users/BigMama.txt");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(archivo);
            fos.write(texto.getBytes());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try{
                if(fos!= null)
                    fos.close();
            }catch (IOException e){
                throw new RuntimeException(e);
            }
        }


    }
}
