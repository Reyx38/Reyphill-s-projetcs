package com.agenda.agenda;
import com.agenda.agenda.Modelos.Contacto;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javax.swing.text.html.ImageView;

public class NuevoView {

        @FXML
        private TextField TextDireccion;

        @FXML
        private ImageView ImagenAgregar;

        @FXML
        private TextField TextEmail;

        @FXML
        private TextField TextId;

        @FXML
        private TextField TextNombre;

        @FXML
        private TextField TextSueldo;

        @FXML
        private TextField TextTelefono;

        public Contacto getContacto(){
            Contacto c = new Contacto();
            c.setId(Integer.parseInt(TextId.getText()));
            c.setNombre(TextNombre.getText());
            c.setTelefono(TextTelefono.getText());
            c.setEmail(TextEmail.getText());
            c.setSaldo(Double.parseDouble(TextSueldo.getText()));
            c.setDireccion(TextDireccion.getText());
            return c;
        }

        public void Modificar(Contacto c){
            TextId.setText(String.valueOf(c.getId()));
            TextNombre.setText(c.getNombre());
            TextDireccion.setText(c.getDireccion());
            TextTelefono.setText(c.getTelefono());
            TextEmail.setText(c.getEmail());
            TextSueldo.setText(String.valueOf(c.getSaldo()));
        }
}
