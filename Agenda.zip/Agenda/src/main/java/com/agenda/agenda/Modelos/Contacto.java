package com.agenda.agenda.Modelos;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter


public class Contacto {
    private int id;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private double saldo;
    public Contacto(){
        id = 0;
        nombre = null;
        direccion = null;
        telefono = null;
        email = null;
        saldo = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
