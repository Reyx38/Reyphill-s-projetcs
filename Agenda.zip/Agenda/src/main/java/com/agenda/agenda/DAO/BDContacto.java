package com.agenda.agenda.DAO;

import com.agenda.agenda.Modelos.Contacto;
import lombok.Getter;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;

public class BDContacto {
    private List<Contacto> data;

    public int capacidad(){return data.size();}

    public BDContacto(){
        this.data = new ArrayList<>();
    }
    public void Agregar(Contacto c){
        data.add(c);
    }
    public Contacto[] list(){
        return  data.toArray(new Contacto[1]);
    }
    public Contacto find(int id){
        for(int i = 0; i < data.size();i++){
            if(id==data.get(i).getId()){
                return data.get(i);
            }
        }
        return null;
    }
    public void edit(Contacto c, int i) {
        this.data.set(i, c);
    }
    public void Eliminar(int i){data.remove(i);}
    public Contacto[] deben(){
        List<Contacto> deben = new ArrayList<>();
        for(int i = 0; i< data.size();i++){
            if (data.get(i).getSaldo() < 0.00 ){
              deben.add(data.get(i));
            }
        }
        return deben.toArray(new Contacto[1]);
    }
}
