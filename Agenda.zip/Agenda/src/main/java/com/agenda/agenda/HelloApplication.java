package com.agenda.agenda;

import com.agenda.agenda.DAO.BDContacto;
import com.agenda.agenda.Modelos.Contacto;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    public static BDContacto bd = new BDContacto();
    @Override
    public void start(Stage stage) throws IOException {
        Contacto c = new Contacto();
        c.setNombre("Juan perez");
        c.setDireccion("SFM");
        c.setEmail("JuanPerez@06gmail.com");
        c.setId(1);
        c.setSaldo(700);
        c.setTelefono("829-244-8240");
        bd.Agregar(c);
        c = new Contacto();
        c.setNombre("Maria Jimenez");
        c.setDireccion("Nagua");
        c.setEmail("MariaJimez@09gmail.com");
        c.setId(2);
        c.setSaldo(900);
        c.setTelefono("829-244-9840");
        bd.Agregar(c);
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Agenda-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Agenda kbraa");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}