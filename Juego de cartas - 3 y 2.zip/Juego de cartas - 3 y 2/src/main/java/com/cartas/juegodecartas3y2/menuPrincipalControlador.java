package com.cartas.juegodecartas3y2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ResourceBundle;

public class menuPrincipalControlador implements Initializable {

    @FXML
    private Button empezarButton;

    @FXML
    private Button salirButtom;

    tableroPrincipalControlador tpc =  new tableroPrincipalControlador();

    @FXML
    void empezarClick(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SeleccionJugadores.fxml"));

    }

    @FXML
    void salirClick(ActionEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableroPrincipalControlador tpc =  new tableroPrincipalControlador();
    }
}