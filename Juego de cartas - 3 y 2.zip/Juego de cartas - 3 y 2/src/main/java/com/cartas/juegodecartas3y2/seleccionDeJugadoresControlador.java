package com.cartas.juegodecartas3y2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class seleccionDeJugadoresControlador {

    @FXML
    private Button PJbuttom;

    @FXML
    private Button SJbuttom;

    @FXML
    private Button TJButtom;

    @FXML
    private Button Tjbuttom;

    @FXML
    void PJclick(ActionEvent event) {

    }

    @FXML
    void SJclick(ActionEvent event) {

    }

    @FXML
    void TJClick(ActionEvent event) {

    }

    @FXML
    void TJclick(ActionEvent event) {

    }

}
