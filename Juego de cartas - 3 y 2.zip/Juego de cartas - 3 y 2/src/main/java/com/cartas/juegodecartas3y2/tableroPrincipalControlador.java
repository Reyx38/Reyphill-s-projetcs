package com.cartas.juegodecartas3y2;

import com.cartas.juegodecartas3y2.Cartas.Baraja;
import com.cartas.juegodecartas3y2.Cartas.Cartas;
import com.cartas.juegodecartas3y2.Jugadores.Jugador;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class tableroPrincipalControlador implements Initializable {

    @FXML
    private Pane Cambiopane;

    @FXML
    private Pane CartaNuevaSelecionada;

    @FXML
    private Pane CartaPilaPane;

    @FXML
    private Button cambiarButtoom;

    @FXML
    private ImageView cartaImagen;

    @FXML
    private Label numeroCarta2;

    @FXML
    private Label numeroCarta3;

    @FXML
    private Label numeroCarta4;

    @FXML
    private Label numeroCarta5;

    @FXML
    private Label numeroLabel;

    @FXML
    private Label numeroLabel1;

    @FXML
    private Label numerocarta1;
    @FXML
    private TextField cambiarTextField;

    @FXML
    private Button quedarmeCartabutton1;

    @FXML
    private Label tipoCarta2;

    @FXML
    private Label tipoCarta3;

    @FXML
    private Label tipoCarta4;

    @FXML
    private Label tipoCarta5;

    @FXML
    private Label tipoLabel;

    @FXML
    private Label tipoLabel1;

    @FXML
    private Label tipocarta2;


    public Baraja b;
    Cartas aux;
    Jugador j;
    private int contador = 0;
    boolean CartaOcupada = false;


    @FXML
    void CartaClick(MouseEvent event) {
        boolean buscar = false;
        contador++;

       if(!CartaOcupada){
           if(contador > 52){
               Dialog d = new Dialog<>();
               d.setTitle("Baraja Vacia...");
               d.setContentText("No hay mas cartas en la baraja.");
               ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
               d.getDialogPane().getButtonTypes().add(okbt);
               d.showAndWait();

           }else {
               while (!buscar){
                   aux = HelloApplication.jf.buscarCartaNueva(b);
                   if(aux != null) {
                       buscar = true;
                   }
               }
               tipoLabel1.setText(aux.getTipo());
               numeroLabel1.setText(aux.getNumero());
               CartaOcupada = true;
           }
       }else{
           Dialog d = new Dialog<>();
           d.setTitle("No puedes selecionar otra carta...");
           d.setContentText("Ya hay una carta ocupando el espacio.");
           ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
           d.getDialogPane().getButtonTypes().add(okbt);
           d.showAndWait();
       }
    }
    @FXML
    void cartaPilaClick(MouseEvent event) {
       if(!CartaOcupada){
           if(!HelloApplication.jf.pilaCartas.isEmpty()){
               aux = HelloApplication.jf.ultimaCarta();
               HelloApplication.jf.eliminarCartaPila();
               tipoLabel1.setText(aux.getTipo());
               numeroLabel1.setText(aux.getNumero());
               actulizarCartaPila();
               CartaOcupada = true;
               if(HelloApplication.jf.pilaCartas.isEmpty()){
                   actulizarCartaPila();
               }
           }else {
               Dialog d = new Dialog<>();
               d.setTitle("Pila Vacia...");
               d.setContentText("No hay mas cartas en la baraja.");
               ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
               d.getDialogPane().getButtonTypes().add(okbt);
               d.showAndWait();
           }
       }else{
           Dialog d = new Dialog<>();
           d.setTitle("No puedes selecionar otra carta...");
           d.setContentText("Ya hay una carta ocupando el espacio.");
           ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
           d.getDialogPane().getButtonTypes().add(okbt);
           d.showAndWait();
       }

    }
    @FXML
    void CambiarClick(ActionEvent event) {
        if(cambiarTextField.getText() != null){
            int numero = Integer.parseInt(cambiarTextField.getText());
            if (numero > 4 || numero < 0){
                Dialog d = new Dialog<>();
                d.setTitle("El valor no es valido...");
                d.setContentText("Ingrese otro valor......");
                ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
                d.getDialogPane().getButtonTypes().add(okbt);
                d.showAndWait();
            }else{
                cambiarTextField.clear();
                cambiarTextField.setPromptText("Ingrese un numero (0-4)");
                HelloApplication.jf.agregarCartasPila(j.mano[numero]);
                j.mano[numero] = aux;
                actulizarAUX();
                actulizarCartaPila();
                CartaOcupada = false;
            }
        }else{
            Dialog d = new Dialog<>();
            d.setTitle("El valor no es valido...");
            d.setContentText("No puede estar vacio......");
            ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
            d.getDialogPane().getButtonTypes().add(okbt);
            d.showAndWait();
        }
        actulizarMano();
        ganateGanate();
    }

    @FXML
    void dejarCartaClick(ActionEvent event) {
        if(aux != null){
            HelloApplication.jf.agregarCartasPila(aux);
            actulizarAUX();
            actulizarCartaPila();
            CartaOcupada = false;
        }else{
            Dialog d = new Dialog<>();
            d.setTitle("Carta sin seleccionar...");
            d.setContentText("No puedes dejar una carta que no haz seleccionado.");
            ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
            d.getDialogPane().getButtonTypes().add(okbt);
            d.showAndWait();
        }

    }

    public void actulizarCartaPila(){
        if(HelloApplication.jf.pilaCartas.isEmpty()){
            tipoLabel.setText("--");
            numeroLabel.setText("--");

        }else {
            Cartas pila = HelloApplication.jf.ultimaCarta();
            tipoLabel.setText(pila.getTipo());
            numeroLabel.setText(pila.getNumero());
        }
    }

    public void actulizarAUX(){
            tipoLabel1.setText("--");
            numeroLabel1.setText("--");
            aux = null;
    }

    public void actulizarMano(){
        numerocarta1.setText(j.mano[0].getNumero());
        tipocarta2.setText(j.mano[0].getTipo());
        numeroCarta2.setText(j.mano[1].getNumero());
        tipoCarta2.setText(j.mano[1].getTipo());
        numeroCarta3.setText(j.mano[2].getNumero());
        tipoCarta3.setText(j.mano[2].getTipo());
        numeroCarta4.setText(j.mano[3].getNumero());
        tipoCarta4.setText(j.mano[3].getTipo());
        tipoCarta5.setText(j.mano[4].getTipo());
        numeroCarta5.setText(j.mano[4].getNumero());
    }
    public void ganateGanate(){
        if(j.ganeGane()){
            Dialog d = new Dialog<>();
            d.setTitle("Ganador!!!!!...");
            d.setContentText("El mejor, La bestia, the best!!!!!!!.");
            ButtonType okbt = new ButtonType("ok",ButtonType.OK.getButtonData());
            d.getDialogPane().getButtonTypes().add(okbt);
            d.showAndWait();
            System.exit(0);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        b = new Baraja();
        Cartas aux = new Cartas();
        j = new Jugador();
        HelloApplication.jf.repartir(j,b);
        actulizarMano();
    }
}
