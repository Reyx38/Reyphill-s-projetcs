package com.cartas.juegodecartas3y2.Cartas;

public class Cartas {
    private String tipo;
    private String numero;
    private int pos;

    public Cartas(String tipo, int pos) {
        this.tipo = tipo;
        this.pos = pos;
        this.numero = convertPosToNumero(pos);
    }

    public Cartas() {
        tipo = null;
        numero = "";
        pos = 0; // Valor por defecto, puede ser cambiado si es necesario
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
        this.pos = convertNumeroToPos(numero); // Actualiza la posición cuando se cambia el número
    }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        if (pos < 1 || pos > 13) {
            throw new IllegalArgumentException("Posición debe estar entre 1 y 13.");
        }
        this.pos = pos;
        this.numero = convertPosToNumero(pos); // Actualiza el número cuando se cambia la posición
    }
    public void mostrarCarta(){
        System.out.println(getNumero()+ " de " + getTipo());
    }

    @Override
    public String toString() {
        if (pos < 1 || pos > 13) {
            throw new IllegalArgumentException("Posición de la carta debe estar entre 1 y 13.");
        }
        return numero + " de " + tipo;
    }

    // Convertir posición a número en formato texto
    private String convertPosToNumero(int pos) {
        String[] valores = {"As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        if (pos < 1 || pos > 13) {
            throw new IllegalArgumentException("Posición debe estar entre 1 y 13.");
        }
        return valores[pos - 1];
    }

    // Convertir número en formato texto a posición
    private int convertNumeroToPos(String numero) {
        switch (numero) {
            case "As": return 1;
            case "2": return 2;
            case "3": return 3;
            case "4": return 4;
            case "5": return 5;
            case "6": return 6;
            case "7": return 7;
            case "8": return 8;
            case "9": return 9;
            case "10": return 10;
            case "J": return 11;
            case "Q": return 12;
            case "K": return 13;
            default: throw new IllegalArgumentException("Número de carta no válido.");
        }
    }
}
