package com.cartas.juegodecartas3y2.Jugadores;

import com.cartas.juegodecartas3y2.Cartas.Baraja;
import com.cartas.juegodecartas3y2.Cartas.Cartas;
import com.cartas.juegodecartas3y2.Juego.juegoFuncionamiento;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Jugador {
    private String nombre;
    public Cartas[] mano;
    private BufferedReader br;

    public Jugador() {
        nombre = "Juan";
        mano = new Cartas[5];
        for (int i = 0; i < mano.length; i++) {
            mano[i] = new Cartas();
        }
        br = new BufferedReader(new InputStreamReader(System.in));
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //metodos

    public void sacarJugada(Baraja b, juegoFuncionamiento jf){
        boolean encotrada =  false;
        System.out.println("Ingrese la carta que desea dejar de su mano");
        try {
            System.out.print("El tipo de carta: ");
            String tipo = br.readLine();
            System.out.print("El numero de carta: ");
            String numero = br.readLine();
            for(int i = 0; i < mano.length;i++){
                if(mano[i].getNumero().equalsIgnoreCase(numero) && mano[i].getTipo().equalsIgnoreCase(tipo)){
                    System.out.print("Ha soltada ");
                    mano[i].mostrarCarta();
                    mano[i] = null;
                    jf.agregarCartasPila(mano[i]);
                    encotrada = true;
                    break;
                }
            }
            if(!encotrada){
                System.out.println("Usted no posee esa carta. Intentelo de nuevo.");
                sacarJugada(b, jf);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void agregarCartaNueva(Cartas c){
        for(int i = 0; i < mano.length; i++){
            if(mano[i] == null){
                mano[i] = c;
                break;
            }
        }
    }

    public Boolean ganeGane(){
        int[] count = new int[13]; // Array para contar ocurrencias de cada número (0-12 para As, 2-10, J, Q, K)
        String[] valores = {"As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

        // Contar ocurrencias
        for (Cartas carta : mano) {
            if (carta != null) {
                String numero = carta.getNumero();
                int index = -1;

                // Encontrar el índice del número en el array de valores
                for (int i = 0; i < valores.length; i++) {
                    if (valores[i].equals(numero)) {
                        index = i;
                        break;
                    }
                }

                if (index != -1) {
                    count[index]++;
                }
            }
        }

        boolean foundTrio = false;
        boolean foundPair = false;

        for (int cnt : count) {
            if (cnt == 3) {
                foundTrio = true;
            } else if (cnt == 2) {
                foundPair = true;
            }
        }

        return foundTrio && foundPair;
    }

    public void llenarMano(String N, String tipo,int i){
        if (mano[i] != null){
            mano[i].setTipo(tipo);
            mano[i].setNumero(N);
        }
    }

    public void mostrarCartas(){
        System.out.println(getNombre() + " Las cartas en tu mano son :");
        for (Cartas carta : mano) {
            if (carta != null) {
                System.out.println(carta);
            }
        }
    }

}
