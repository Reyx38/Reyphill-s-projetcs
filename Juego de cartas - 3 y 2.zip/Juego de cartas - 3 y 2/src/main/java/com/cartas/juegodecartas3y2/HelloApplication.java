package com.cartas.juegodecartas3y2;

import com.cartas.juegodecartas3y2.Cartas.Baraja;
import com.cartas.juegodecartas3y2.Cartas.Cartas;
import com.cartas.juegodecartas3y2.Juego.juegoFuncionamiento;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    Baraja b = new Baraja();
    Cartas c = new Cartas();
    static juegoFuncionamiento jf = new juegoFuncionamiento();

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("tableroPrincipal-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Juego de cartas: 3 y 2");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}