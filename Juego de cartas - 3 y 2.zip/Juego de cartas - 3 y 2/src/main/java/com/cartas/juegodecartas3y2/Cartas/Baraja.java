package com.cartas.juegodecartas3y2.Cartas;

public class Baraja {
    static public final String[] TIPOS = {"Corazon", "Diamante" , "Pica" , "Trebol"};
    private Cartas cartaMazos[][];

    public Baraja() {
        cartaMazos = new Cartas[TIPOS.length][13];
        generarMazo();
    }

    public void generarMazo(){
        for(int i = 0 ;i < TIPOS.length; i++){
            for(int j = 0; j < 13; j++){
                cartaMazos[i][j] = new Cartas(TIPOS[i],j+1 );
            }
        }
    }

    public Cartas getCarta(int tipo,int numero){
        return cartaMazos[tipo][numero];
    }

    public String getNumero(int tipo,int numero){
        Cartas valor = cartaMazos[tipo][numero];
        return valor.getNumero();
    }

    public boolean CartaDisponible(int tipo, int numero){
        if(cartaMazos[tipo][numero] != null){
            return true;
        }
        return false;
    }

    public void ActulizarBaraja(int tipo ,int numero){
        cartaMazos[tipo][numero] = null;
    }

    public void MostrarBaraja(){
        for (int i = 0; i < TIPOS.length; i++) {
            System.out.println("Mazo de " + TIPOS[i] + ":");
            for (Cartas carta : cartaMazos[i]) {
                System.out.println(carta);
            }
            System.out.println();
        }
    }
}
