package com.cartas.juegodecartas3y2;

import com.cartas.juegodecartas3y2.Cartas.Baraja;
import com.cartas.juegodecartas3y2.Cartas.Cartas;
import com.cartas.juegodecartas3y2.Juego.juegoFuncionamiento;
import com.cartas.juegodecartas3y2.Jugadores.Jugador;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    static final String INTRO = """
                                         :~~~~~~~~~~~~~~~~~~~~~~~~~:
                                         :     Juego de cartas     :
                                         :          3 y 2          :     
                                         :~~~~~~~~~~~~~~~~~~~~~~~~~:        
                                """;

    static final String menu = """
                                        1) 1 jugador
                                        2) 2 jugadores
                                        3) 3 jugadores
                                        4) 4 jugadores
                               """;
    public static void main(String[] args) throws IOException {
        Baraja b = new Baraja();
        juegoFuncionamiento jf = new juegoFuncionamiento();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String quieres;
        Cartas aux;

        System.out.println(INTRO);
        System.out.println(menu);
        System.out.println("Ingrese la opcion (1-4):" );
        int N = Integer.parseInt(br.readLine());
        Jugador[] jug = new Jugador[N];
        for(int i = 0; i < N ;i++){
            jug[i] = new Jugador();
            System.out.print("Ingrese el nombre del jugador " + (i+1) + ":"  );
            jug[i].setNombre(br.readLine());
            System.out.println();
            jf.repartir(jug[i],b);
        }

       while (!jf.acabar){
           for(int i = 0 ; i < N ; i++){
               try {
                   jug[i].mostrarCartas();
                   System.out.print("De donde desea sacar la carta (pila o  baraja): ");
                   String decision = br.readLine();
                   switch (decision.toLowerCase()){
                       case "baraja":
                           System.out.print("La carta nueva es: ");
                           aux = jf.buscarCartaNueva(b);
                           System.out.print("Desea quedarse con la carta (S/N): ");
                           quieres = br.readLine();
                           if(quieres.equalsIgnoreCase("s")) {
                               jug[i].sacarJugada(b,jf);
                               jug[i].agregarCartaNueva(aux);
                               jug[i].mostrarCartas();
                           }else{
                               jf.agregarCartasPila(aux);
                           }
                           break;
                       case "pila" :
                           System.out.print("La carta de la pila es: ");
                           aux = jf.obtenerCartapila();
                           System.out.print("Desea quedarse con la carta (S/N): ");
                           quieres = br.readLine();
                           if(quieres.equalsIgnoreCase("s")) {
                               jug[i].sacarJugada(b,jf);
                               jug[i].agregarCartaNueva(aux);
                               jug[i].mostrarCartas();
                           }else{
                               jf.agregarCartasPila(aux);
                           }
                           break;
                       default:
                           System.out.println("Esa opcion es incorrecta");
                   }
                   if (jug[i].ganeGane()) {
                       System.out.println("¡" + jug[i].getNombre() + " ha ganado el juego!");
                       jf.acabar = true;
                       break;
                   }
                   System.out.println("El turno de " + jug[i].getNombre()+ " ha acabado");
                   System.out.println("----------------------------------------------");

               } catch (IOException e) {
                   throw new RuntimeException(e);
               }
           }
       }
    }

}
