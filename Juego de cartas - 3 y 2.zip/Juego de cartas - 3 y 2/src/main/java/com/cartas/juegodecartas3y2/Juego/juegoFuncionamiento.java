package com.cartas.juegodecartas3y2.Juego;

import com.cartas.juegodecartas3y2.Cartas.Baraja;
import com.cartas.juegodecartas3y2.Cartas.Cartas;
import com.cartas.juegodecartas3y2.Jugadores.Jugador;


import java.util.LinkedList;
import java.util.Random;

public class juegoFuncionamiento  {
    private boolean iniciar;
    public boolean acabar;
    public LinkedList<Cartas> pilaCartas;

    public juegoFuncionamiento() {
        this.acabar = false;
        this.iniciar = true;
        this.pilaCartas = new LinkedList<>();
    }

    public void eliminarCartaPila(){
        pilaCartas.removeLast();
    }

    public Cartas ultimaCarta(){
        return pilaCartas.getLast();
    }


    public boolean terminar(){
        return acabar = true;
    }

    public void agregarCartasPila(Cartas c){
        pilaCartas.add(c);
    }


    public Cartas obtenerCartapila(){
        if(!pilaCartas.isEmpty()){
            Cartas recuperada = pilaCartas.removeFirst();
            System.out.print("Ha tomado ");
            recuperada.mostrarCarta();
            return recuperada;
        }else{
            System.out.println("La pila esta vacia. No puedes tomar cartas.");
            return null;
        }
    }

    public void mostrarPila(){
        for(Cartas cartas : pilaCartas){
            System.out.println(cartas);
        }
    }

    public Cartas buscarCartaNueva(Baraja b){
        Random N = new Random();
        int IT = N.nextInt(4);
        int IN = N.nextInt(13);
        if(b.CartaDisponible(IT,IN)){
            Cartas cartaNueva = b.getCarta(IT,IN);
            cartaNueva.mostrarCarta();
            b.ActulizarBaraja(IT,IN);
            return cartaNueva;
        }else {
            return null;
        }
    }

    public void repartir(Jugador jug, Baraja b) {
        Random N = new Random();
        for (int i = 0; i < 5 ; i++) {
            int IT = N.nextInt(4);
            int IN = N.nextInt(13);
            if (b.CartaDisponible(IT, IN)) {
                jug.llenarMano(b.getNumero(IT,IN),Baraja.TIPOS[IT],i);
                b.ActulizarBaraja(IT,IN);
            }else{
                i--;
            }
        }

    }
}
